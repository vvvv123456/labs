package mk.ukim.finki.wp.lab.repository.impl;

import mk.ukim.finki.wp.lab.bootstrap.dataHolder;
import mk.ukim.finki.wp.lab.model.Chef;
import mk.ukim.finki.wp.lab.repository.ChefRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public class InMemoryChefRepository implements ChefRepository {
    @Override
    public List<Chef> findAll() {
        return dataHolder.chefs;
    }

    @Override
    public Optional<Chef> findById(Long id) {
        return dataHolder.chefs.stream().filter(chef -> chef.getId().equals(id)).findFirst();
    }

    @Override
    public Chef save(Chef chef) {
        if(dataHolder.chefs.contains(chef)){
            int index = dataHolder.chefs.indexOf(chef);
            dataHolder.chefs.set(index, chef);
        }
        else{
            dataHolder.chefs.add(chef);
        }
        return chef;
    }
}
